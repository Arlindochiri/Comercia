import React from 'react'

const CartDetails = () => {
  return (
    <div>CartDetails</div>
  )
}

export default CartDetails