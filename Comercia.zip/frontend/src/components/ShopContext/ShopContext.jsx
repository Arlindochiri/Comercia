import React from 'react'

const ShopContext = () => {
  return (
    <div>ShopContext</div>
  )
}

export default ShopContext