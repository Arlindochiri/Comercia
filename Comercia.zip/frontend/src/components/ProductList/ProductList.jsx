import React from 'react'

const ProductList = () => {
  return (
    <div>ProductList</div>
  )
}

export default ProductList