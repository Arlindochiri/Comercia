import watch1 from './assets/watch1.jpg'
import watch2 from './assets/watch2.jpg'
import watch3 from './assets/watch3.jpg'
import watch4 from './assets/watch4.jpg'
import watch5 from './assets/watch5.jpg'
import watch6 from './assets/watch6.jpg'
import watch7 from './assets/watch7.jpg'
import watch8 from './assets/watch8.jpg'
import watch9 from './assets/watch9.jpg'
import watch10 from './assets/watch10.jpg'
import watch11 from './assets/watch11.jpg'
import watch12 from './assets/watch12.jpg'
import watch13 from './assets/watch13.jpg'
import watch14 from './assets/watch14.jpg'
import watch15 from './assets/watch15.jpg'



export const productsData = [
    {
        id: 1,
        image : watch1,
        title: "Ladies Silver watch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 2,
        image : watch2,
        title: "Non Tarnish Wristwatch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 3,
        image : watch3,
        title: "Casio Silver Office Watch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 4,
        image : watch4,
        title: "Men Gold Wristwatch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 5,
        image : watch5,
        title: "Timezone Wristwatch Male",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 6,
        image : watch6,
        title: "Shinning Diamond Watch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 7,
        image : watch7,
        title: "Non Tarnish Leather",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 8,
        image : watch8,
        title: "Unisex Black Smart Watch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 9,
        image : watch9,
        title: "Black Portable Wristwatch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 10,
        image : watch10,
        title: "Leather Green Wristwatch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 11,
        image : watch11,
        title: "Gold Bracelet Wristwatch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 12,
        image : watch12,
        title: "2piece Gold Wristwatch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 13,
        image : watch13,
        title: "Unisex Black Smart Watch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 14,
        image : watch14,
        title: "Wristwatch and Necklace",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },
    {
        id: 15,
        image : watch15,
        title: "Complete Set Wristwatch",
        price: 85,
        category: 'men',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Asperiores nulla eos fuga maiores dolore, cum facere aperiam doloremque praesentium totam expedita quibusdam excepturi necessitatibus autem perspiciatis sunt eligendi minima quam.',
    },

]